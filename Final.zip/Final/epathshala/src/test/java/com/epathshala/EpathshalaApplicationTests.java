package com.epathshala;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpathshalaApplicationTests {

    @Test
    void contextLoads() {
    }
}