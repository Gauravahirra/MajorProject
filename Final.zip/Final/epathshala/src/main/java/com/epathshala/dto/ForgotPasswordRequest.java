package com.epathshala.dto;

import lombok.Data;

@Data
public class ForgotPasswordRequest {
    private String email;
} 