import React from 'react';
import ParentChildProgressSection from './ParentChildProgressSection';

function ParentChildProgressPage() {
  return (
    <ParentChildProgressSection />
  );
}

export default ParentChildProgressPage;
