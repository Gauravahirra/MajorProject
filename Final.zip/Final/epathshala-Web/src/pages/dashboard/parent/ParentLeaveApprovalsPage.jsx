import React from 'react';
import ParentLeaveApprovalSection from './ParentLeaveApprovalSection';

function ParentLeaveApprovalsPage() {
  return (
    <ParentLeaveApprovalSection />
  );
}

export default ParentLeaveApprovalsPage;
