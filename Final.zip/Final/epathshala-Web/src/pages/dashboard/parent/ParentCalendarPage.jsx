import React from 'react';
import ParentCalendarSection from './ParentCalendarSection';

function ParentCalendarPage() {
  return (
    <ParentCalendarSection />
  );
}

export default ParentCalendarPage;
